import {NextResponse} from 'next/server';
import {writeFile, mkdir} from 'fs/promises';
import path from 'path';
import {enqueueConvert} from '../../../lib/redis';

// Must match the shared volume mount path used by the worker container
// (see UPLOADS_DIR in docker-compose.yml — both services mount the same
// named volume so the worker can read the file this route writes).
const UPLOADS_DIR = process.env.UPLOADS_DIR || '/shared-uploads';
const ALLOWED_EXT = ['.zip', '.tar.gz', '.tgz'];
const MAX_BYTES = 300 * 1024 * 1024;

export async function POST(req: Request) {
  const formData = await req.formData();
  const file = formData.get('file') as File | null;

  if (!file) {
    return NextResponse.json({error: 'file is required'}, {status: 400});
  }
  if (!ALLOWED_EXT.some(ext => file.name.toLowerCase().endsWith(ext))) {
    return NextResponse.json({error: `Unsupported file type. Allowed: ${ALLOWED_EXT.join(', ')}`}, {status: 400});
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({error: 'File exceeds max upload size'}, {status: 413});
  }

  await mkdir(UPLOADS_DIR, {recursive: true});
  const safeName = `${crypto.randomUUID()}-${file.name.replace(/[^\w.\-]/g, '_')}`;
  const destPath = path.join(UPLOADS_DIR, safeName);

  await writeFile(destPath, Buffer.from(await file.arrayBuffer()));

  const jobId = await enqueueConvert(destPath);
  return NextResponse.json({jobId, status: 'queued'});
}
