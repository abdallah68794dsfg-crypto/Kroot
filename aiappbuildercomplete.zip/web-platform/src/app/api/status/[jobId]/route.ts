import {NextResponse} from 'next/server';
import {getJobStatus} from '../../../../lib/redis';

export async function GET(_:Request,{params}:{params:{jobId:string}}){
  const data = await getJobStatus(params.jobId);
  return NextResponse.json({jobId: params.jobId, ...data});
}
