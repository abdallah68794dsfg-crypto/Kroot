'use client'; import {useState} from 'react';
export default function Home(){const [idea,setIdea]=useState('تطبيق مهام بسيط مع تسجيل دخول');const [out,setOut]=useState('');
async function generate(){setOut('جاري التوليد...');const r=await fetch('/api/generate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({idea})});setOut(JSON.stringify(await r.json(),null,2))}
async function uploadProject(e:React.ChangeEvent<HTMLInputElement>){
  const file=e.target.files?.[0]; if(!file) return;
  setOut('جاري رفع المشروع...');
  const fd=new FormData(); fd.append('file',file);
  const r=await fetch('/api/upload',{method:'POST',body:fd});
  setOut(JSON.stringify(await r.json(),null,2));
}
return <main style={{maxWidth:900,margin:'60px auto',padding:24}}><h1>AI App Builder</h1><p>حوّل فكرتك إلى مشروع Android Jetpack Compose، أو ارفع مشروعًا موجودًا.</p>
<textarea rows={7} value={idea} onChange={e=>setIdea(e.target.value)} style={{width:'100%',padding:12}}/>
<button onClick={generate} style={{marginTop:12,padding:12}}>توليد المشروع</button>
<div style={{marginTop:24,paddingTop:24,borderTop:'1px solid #ddd'}}>
  <p>📁 أو ارفع مشروع Android موجود (.zip):</p>
  <input type="file" accept=".zip,.tar.gz,.tgz" onChange={uploadProject}/>
</div>
<pre style={{background:'#f5f5f5',padding:16,whiteSpace:'pre-wrap'}}>{out}</pre></main>}