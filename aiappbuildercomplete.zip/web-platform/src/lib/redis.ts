import Redis from 'ioredis'; let r:Redis|undefined; export function redis(){return r??=new Redis(process.env.REDIS_URL||'redis://localhost:6379')}

export async function enqueueBuild(project:unknown){const id=crypto.randomUUID();await redis().lpush(process.env.BUILD_WORKER_QUEUE||'apk-builds',JSON.stringify({id,type:'generate',project}));return id}

// New: enqueue a "convert" job for an uploaded project archive. archivePath
// must be reachable by the worker container (see the shared `uploads`
// volume in docker-compose.yml).
export async function enqueueConvert(archivePath:string){const id=crypto.randomUUID();await redis().lpush(process.env.BUILD_WORKER_QUEUE||'apk-builds',JSON.stringify({id,type:'convert',archive_path:archivePath}));return id}

export async function getJobStatus(jobId:string){
  const [status,error,result]=await Promise.all([
    redis().get(`job:${jobId}:status`),
    redis().get(`job:${jobId}:error`),
    redis().get(`job:${jobId}:result`),
  ]);
  return {status: status||'queued', error: error||undefined, downloadUrl: result||undefined};
}