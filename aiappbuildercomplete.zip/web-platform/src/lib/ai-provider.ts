import {z} from 'zod';
const Project=z.object({packageName:z.string(),appName:z.string(),manifest:z.string(),mainActivity:z.string(),files:z.record(z.string())}); export type Project=z.infer<typeof Project>;
export async function generateProject(idea:string):Promise<Project>{if((process.env.AI_PROVIDER||'mock')==='mock')return mock(idea);throw new Error('Connect the selected AI provider in ai-provider.ts and validate its JSON against the Project schema.')}
function mock(idea:string):Project{return Project.parse({packageName:'com.generated.app',appName:'Generated App',manifest:'<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>',mainActivity:`package com.generated.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{Text("${idea.replaceAll('"','\\\"').replaceAll('\n',' ')}")}}}`,files:{}})}