import os, asyncio, httpx
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

ALLOWED_EXT = (".zip", ".tar.gz", ".tgz")
MAX_TELEGRAM_FILE_MB = 50

load_dotenv()
TOKEN=os.environ["TELEGRAM_BOT_TOKEN"]
API=os.getenv("WEB_API_URL","http://web:3000").rstrip("/")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 أهلاً بك في AI App Builder Bot\n\n"
        "أرسل فكرة تطبيق Android بالتفصيل، وسأحوّلها إلى مشروع Jetpack Compose ثم أرسل لك الـ APK بعد البناء.\n\n"
        "مثال:\nتطبيق إدارة مصروفات مع تسجيل دخول، إضافة مصروف، تقارير شهرية."
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("أرسل فكرة التطبيق فقط. كلما كانت المتطلبات أوضح كانت النتيجة أفضل.")

async def idea(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text=(update.message.text or "").strip()
    if len(text)<5:
        await update.message.reply_text("اكتب وصفاً أطول لفكرة التطبيق.")
        return
    await update.message.reply_text("🧠 أحلل الفكرة وأولّد ملفات Android...")
    try:
        async with httpx.AsyncClient(timeout=180) as c:
            r=await c.post(f"{API}/api/generate",json={"idea":text})
            r.raise_for_status()
            project=r.json()["project"]
            b=await c.post(f"{API}/api/build",json={"project":project})
            b.raise_for_status()
            job=b.json()["jobId"]
        context.application.bot_data.setdefault("jobs",{})[job]=update.effective_chat.id
        keyboard=InlineKeyboardMarkup([[InlineKeyboardButton("🔄 حالة البناء",callback_data=f"status:{job}")]])
        await update.message.reply_text(
            f"✅ تم إنشاء المشروع: {project.get('appName','Android App')}\n"
            f"📦 بدأت عملية بناء APK.\n\nJob: {job}",
            reply_markup=keyboard
        )
        asyncio.create_task(poll_job(context, job, update.effective_chat.id))
    except Exception as e:
        await update.message.reply_text(f"❌ حدث خطأ: {e}")

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """New: user sends an existing Android project archive to convert/build."""
    doc = update.message.document
    filename = doc.file_name or ""

    if not filename.lower().endswith(ALLOWED_EXT):
        await update.message.reply_text("⚠️ صيغة غير مدعومة. أرسل ملف .zip أو .tar.gz فقط.")
        return
    if doc.file_size and doc.file_size > MAX_TELEGRAM_FILE_MB * 1024 * 1024:
        await update.message.reply_text(f"⚠️ الملف أكبر من {MAX_TELEGRAM_FILE_MB}MB. استخدم واجهة الويب لملفات أكبر.")
        return

    await update.message.reply_text("📁 تم استلام المشروع\n🔍 جاري الرفع والتحليل...")

    tg_file = await doc.get_file()
    file_bytes = await tg_file.download_as_bytearray()

    try:
        async with httpx.AsyncClient(timeout=60) as c:
            files = {"file": (filename, bytes(file_bytes))}
            r = await c.post(f"{API}/api/upload", files=files)
            r.raise_for_status()
            job = r.json()["jobId"]
    except Exception as e:
        await update.message.reply_text(f"❌ فشل الرفع: {e}")
        return

    keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("🔄 حالة البناء", callback_data=f"status:{job}")]])
    await update.message.reply_text(f"🔨 بدأ تحليل وبناء المشروع.\n\nJob: {job}", reply_markup=keyboard)
    asyncio.create_task(poll_job(context, job, update.effective_chat.id))


async def poll_job(context, job, chat_id):
    for _ in range(60):
        await asyncio.sleep(5)
        try:
            async with httpx.AsyncClient(timeout=30) as c:
                r=await c.get(f"{API}/api/status/{job}")
                data=r.json()
            status=data.get("status")
            if status=="completed":
                url=data.get("downloadUrl")
                await context.bot.send_message(chat_id, f"🎉 اكتمل البناء!\n📥 {url or 'تم حفظ APK في التخزين.'}")
                return
            if status=="failed":
                await context.bot.send_message(chat_id, f"❌ فشل البناء:\n{data.get('error','Unknown error')}")
                return
        except Exception:
            pass
    await context.bot.send_message(chat_id,"⏳ البناء ما زال يعمل. استخدم زر حالة البناء لاحقاً.")

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query
    await q.answer()
    if not q.data.startswith("status:"): return
    job=q.data.split(":",1)[1]
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r=await c.get(f"{API}/api/status/{job}")
            data=r.json()
        msg=f"📦 الحالة: {data.get('status','unknown')}"
        if data.get("downloadUrl"): msg+=f"\n📥 {data['downloadUrl']}"
        await q.message.reply_text(msg)
    except Exception as e:
        await q.message.reply_text(f"تعذر جلب الحالة: {e}")

def main():
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CommandHandler("help",help_cmd))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,idea))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.run_polling()

if __name__=="__main__": main()
