# Telegram Bot Edition

هذا المجلد يضيف نسخة Telegram Bot إلى AI App Builder.

## التشغيل
1. أنشئ Bot من BotFather وخذ `TELEGRAM_BOT_TOKEN`.
2. انسخ `.env.example` إلى `.env`.
3. اجعل `WEB_API_URL` يشير إلى منصة Next.js.
4. شغّل:
   `pip install -r requirements.txt`
   `python -m app.bot`

## التدفق
Telegram -> /api/generate -> /api/build -> Redis -> Build Worker -> /api/status -> APK URL

## مهم
يجب استبدال endpoint الحالة الحالي في منصة الويب بقراءة حقيقية من Redis/قاعدة البيانات وإرجاع:
`queued | building | completed | failed`
ومع `completed` يرجع `downloadUrl`.
