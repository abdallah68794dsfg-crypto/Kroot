# AI App Builder — النسخة الكاملة المدمجة

هذا هو مشروعك الأصلي (web-platform + telegram-bot + build-worker +
android-template) بعد دمج قدرة **تحويل مشروع مرفوع إلى APK** فيه، وإصلاح
مشكلة Gradle التي كانت تمنع البناء أساسًا.

## ما الذي تغيّر عن نسختك الأصلية

| الملف | التغيير |
|---|---|
| `build-worker/Dockerfile.android` | 🔧 **إصلاح جوهري**: كان يثبّت JDK فقط. أضفت تثبيت Android SDK (platform 35 + build-tools) وGradle 8.9 فعليًا — بدونهما `gradlew` (الذي هو مجرد `exec gradle "$@"`) يفشل بـ `gradle: not found` كما رأينا. |
| `build-worker/app/archive_handler.py` | 🆕 جديد — فك آمن للـZIP/TAR.GZ (حماية zip-slip) |
| `build-worker/app/project_detector.py` | 🆕 جديد — يتحقق أن المشروع المرفوع Android/Gradle صالح |
| `build-worker/app/scanner.py` | 🆕 جديد — يستخرج dependencies/SDK versions/manifest |
| `build-worker/app/worker.py` | ✏️ معدّل — الآن يتعامل مع نوعين من المهام: `generate` (فكرة → تطبيق، كما كان) و`convert` (مشروع مرفوع → APK، جديد) |
| `web-platform/src/lib/redis.ts` | ✏️ معدّل — أضفت `enqueueConvert()` و`getJobStatus()` الحقيقية (كانت `/api/status` ترجع `"queued"` ثابتة دائمًا) |
| `web-platform/src/app/api/status/[jobId]/route.ts` | 🔧 **إصلاح**: كان يرجّع حالة وهمية ثابتة بغض النظر عن الحالة الفعلية. الآن يقرأ من Redis فعليًا. |
| `web-platform/src/app/api/upload/route.ts` | 🆕 جديد — رفع أرشيف المشروع وتفعيل مهمة `convert` |
| `web-platform/src/app/page.tsx` | ✏️ معدّل — أضفت زر رفع ملف |
| `telegram-bot/app/bot.py` | ✏️ معدّل — أضفت استقبال ملفات Android من المستخدم مباشرة |
| `docker-compose.yml` | ✏️ معدّل — أضفت volume مشترك `shared-uploads` بين web وworker |

## التشغيل

```bash
# 1. انسخ ملفات البيئة
cp web-platform/.env.example web-platform/.env
cp telegram-bot/.env.example telegram-bot/.env
cp build-worker/.env.example build-worker/.env

# 2. عبّي على الأقل:
#    telegram-bot/.env -> TELEGRAM_BOT_TOKEN (من BotFather)
#    web-platform/.env -> اتركه AI_PROVIDER=mock للتجربة الأولى بدون مفاتيح AI حقيقية

# 3. شغّل كل شيء (يحتاج إنترنت أول مرة لتحميل Android SDK + Gradle داخل الصورة)
docker compose up --build
```

بعدها:
- الويب: http://localhost:3000
- البوت: أرسل `/start` له على Telegram

## اختبار مسار "رفع مشروع" (الميزة التي طلبتها)

**عبر الويب:** افتح الصفحة الرئيسية، استخدم زر "📁 ارفع مشروع Android موجود" وارفع ملف `.zip` فيه `gradlew` حقيقي.

**عبر Telegram:** أرسل ملف `.zip` مباشرة للبوت (بدون أي أمر).

**ملاحظة مهمة جدًا:** مشروعك في `android-template/` يحتوي `gradlew` وهمي (سطرين فقط يستدعي `gradle` من النظام). هذا يعمل الآن **فقط داخل** `worker` container بعد الإصلاح، لأنه الوحيد اللي فيه Gradle مثبت فعليًا. أي مشروع تختبره (سواء template أو مرفوع من المستخدم) لازم يحتوي `gradlew` (حتى لو كان الشكل المبسط هذا) ليبني بنجاح.

## لماذا لم أختبر البناء الفعلي بنفسي

بيئتي الحالية (التي أنشأت فيها هذه الملفات) بلا اتصال إنترنت، فلا أقدر أُنزّل Android SDK أو Gradle لأختبر بناء APK حقيقي هنا. لكن اختبرت **كل شيء ممكن اختباره بدون ذلك**:
- ✅ تحليل مشروعك المرفوع (`android-template`) بأداتي — نجح 100% في الاستخراج والفحص
- ✅ صياغة/syntax كل ملفات Python المعدّلة (`worker.py` وغيرها) — صحيحة
- ⏳ البناء الفعلي (`gradlew assembleDebug`) — يحتاج تشغيله على جهازك بعد `docker compose up --build`

## الخطوة التالية المقترحة

شغّل `docker compose up --build` على جهاز متصل بالإنترنت، وارفع أي مشروع Android بسيط (فيه `gradlew` حقيقي أو حتى النسخة المبسطة الموجودة عندك) وشاهد النتيجة. لو صادفتك أي رسالة خطأ من Gradle، ارسلها لي وأحللها.
