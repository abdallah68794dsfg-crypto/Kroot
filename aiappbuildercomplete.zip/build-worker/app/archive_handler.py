"""
archive_handler.py
Safely extract user-uploaded ZIP/TAR.GZ archives into an isolated temp directory.

Security notes:
- Prevents "Zip Slip" path traversal (../../etc/passwd style entries).
- Enforces a max extracted size and max file count to avoid zip-bomb DoS.
- Never executes anything from the archive; extraction only.
"""

import os
import tarfile
import zipfile
import tempfile
import shutil
from pathlib import Path
from dataclasses import dataclass


class ArchiveError(Exception):
    pass


@dataclass
class ExtractionLimits:
    max_files: int = 5000
    max_total_uncompressed_bytes: int = 500 * 1024 * 1024  # 500 MB
    max_single_file_bytes: int = 100 * 1024 * 1024          # 100 MB


def _is_within_directory(base_dir: Path, target: Path) -> bool:
    try:
        base_dir = base_dir.resolve()
        target = target.resolve()
    except FileNotFoundError:
        # target doesn't exist yet (normal during extraction planning)
        target = target.absolute()
        base_dir = base_dir.absolute()
    return str(target).startswith(str(base_dir) + os.sep) or target == base_dir


def extract_zip(archive_path: str, dest_dir: str, limits: ExtractionLimits = ExtractionLimits()) -> str:
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(archive_path) as zf:
        infos = zf.infolist()
        if len(infos) > limits.max_files:
            raise ArchiveError(f"Archive has too many files ({len(infos)} > {limits.max_files})")

        total_size = 0
        for info in infos:
            total_size += info.file_size
            if info.file_size > limits.max_single_file_bytes:
                raise ArchiveError(f"File '{info.filename}' exceeds max single-file size limit")
            target_path = dest / info.filename
            if not _is_within_directory(dest, target_path):
                raise ArchiveError(f"Blocked path traversal attempt: {info.filename}")

        if total_size > limits.max_total_uncompressed_bytes:
            raise ArchiveError("Archive exceeds max total uncompressed size limit")

        zf.extractall(dest)

    return str(dest)


def extract_tar(archive_path: str, dest_dir: str, limits: ExtractionLimits = ExtractionLimits()) -> str:
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)

    with tarfile.open(archive_path, "r:*") as tf:
        members = tf.getmembers()
        if len(members) > limits.max_files:
            raise ArchiveError(f"Archive has too many files ({len(members)} > {limits.max_files})")

        total_size = 0
        for member in members:
            if member.issym() or member.islnk():
                raise ArchiveError(f"Symlinks are not allowed in archives: {member.name}")
            total_size += member.size
            if member.size > limits.max_single_file_bytes:
                raise ArchiveError(f"File '{member.name}' exceeds max single-file size limit")
            target_path = dest / member.name
            if not _is_within_directory(dest, target_path):
                raise ArchiveError(f"Blocked path traversal attempt: {member.name}")

        if total_size > limits.max_total_uncompressed_bytes:
            raise ArchiveError("Archive exceeds max total uncompressed size limit")

        tf.extractall(dest)

    return str(dest)


def extract_project(archive_path: str, workspace_root: str = None) -> str:
    """
    Extracts an uploaded project archive into a fresh isolated temp directory
    and returns the path. Caller is responsible for cleanup (see cleanup_workspace).
    """
    workspace_root = workspace_root or tempfile.gettempdir()
    work_dir = tempfile.mkdtemp(prefix="aab_project_", dir=workspace_root)

    lower = archive_path.lower()
    try:
        if lower.endswith(".zip"):
            extract_zip(archive_path, work_dir)
        elif lower.endswith(".tar.gz") or lower.endswith(".tgz"):
            extract_tar(archive_path, work_dir)
        else:
            raise ArchiveError(f"Unsupported archive format: {archive_path}")
    except Exception:
        shutil.rmtree(work_dir, ignore_errors=True)
        raise

    return work_dir


def cleanup_workspace(work_dir: str):
    shutil.rmtree(work_dir, ignore_errors=True)
