"""
scanner.py
Deeper analysis of a detected Android project: parses Gradle files (regex-based,
good enough for metadata extraction without a full Groovy/KTS parser) and
AndroidManifest.xml (via stdlib ElementTree).

Output is a single JSON-serializable ProjectMetadata object — this, not raw
source code, is what should be sent to the AI engine for planning.
"""

import os
import re
import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

DEP_PATTERN = re.compile(
    r'''(?:implementation|api|kapt|ksp|testImplementation|androidTestImplementation)\s*
        \(?\s*["']([\w\.\-:]+):([\w\.\-]+):([\w\.\-\+]+)["']''',
    re.VERBOSE,
)
COMPILE_SDK_PATTERN = re.compile(r'compileSdk(?:Version)?\s*=?\s*"?(\d+)"?')
MIN_SDK_PATTERN = re.compile(r'minSdk(?:Version)?\s*=?\s*"?(\d+)"?')
TARGET_SDK_PATTERN = re.compile(r'targetSdk(?:Version)?\s*=?\s*"?(\d+)"?')
APPLICATION_ID_PATTERN = re.compile(r'applicationId\s*=?\s*"([\w\.]+)"')
KOTLIN_PLUGIN_PATTERN = re.compile(r'kotlin[-\.]android|org\.jetbrains\.kotlin')
COMPOSE_ENABLED_PATTERN = re.compile(r'compose\s*=?\s*true|buildFeatures\s*\{\s*compose\s*true')


@dataclass
class Dependency:
    group: str
    artifact: str
    version: str


@dataclass
class ModuleMetadata:
    name: str
    application_id: Optional[str] = None
    compile_sdk: Optional[int] = None
    min_sdk: Optional[int] = None
    target_sdk: Optional[int] = None
    uses_kotlin: bool = False
    uses_compose: bool = False
    dependencies: list = field(default_factory=list)
    activities: list = field(default_factory=list)
    permissions: list = field(default_factory=list)


@dataclass
class ProjectMetadata:
    root_dir: str
    gradle_type: Optional[str]
    modules: list = field(default_factory=list)   # list[ModuleMetadata]
    warnings: list = field(default_factory=list)


def _read(path: Path) -> str:
    try:
        return path.read_text(errors="ignore")
    except Exception:
        return ""


def _parse_gradle_file(text: str) -> dict:
    deps = [
        Dependency(g, a, v).__dict__
        for (g, a, v) in DEP_PATTERN.findall(text)
    ]
    compile_sdk = COMPILE_SDK_PATTERN.search(text)
    min_sdk = MIN_SDK_PATTERN.search(text)
    target_sdk = TARGET_SDK_PATTERN.search(text)
    app_id = APPLICATION_ID_PATTERN.search(text)

    return dict(
        dependencies=deps,
        compile_sdk=int(compile_sdk.group(1)) if compile_sdk else None,
        min_sdk=int(min_sdk.group(1)) if min_sdk else None,
        target_sdk=int(target_sdk.group(1)) if target_sdk else None,
        application_id=app_id.group(1) if app_id else None,
        uses_kotlin=bool(KOTLIN_PLUGIN_PATTERN.search(text)),
        uses_compose=bool(COMPOSE_ENABLED_PATTERN.search(text)),
    )


def _parse_manifest(manifest_path: Path) -> dict:
    activities, permissions = [], []
    package = None
    if not manifest_path.exists():
        return dict(activities=activities, permissions=permissions, package=package)

    try:
        tree = ET.parse(manifest_path)
        root = tree.getroot()
        package = root.attrib.get("package")

        for perm in root.findall("uses-permission"):
            name = perm.attrib.get(f"{ANDROID_NS}name")
            if name:
                permissions.append(name)

        app_node = root.find("application")
        if app_node is not None:
            for act in app_node.findall("activity"):
                name = act.attrib.get(f"{ANDROID_NS}name")
                is_launcher = any(
                    filt.find(f"category[@{ANDROID_NS}name='android.intent.category.LAUNCHER']") is not None
                    for filt in act.findall("intent-filter")
                )
                activities.append({"name": name, "is_launcher": is_launcher})
    except ET.ParseError as e:
        pass

    return dict(activities=activities, permissions=permissions, package=package)


def scan_module(root: Path, module_name: str) -> ModuleMetadata:
    module_dir = root / module_name
    gradle_kts = module_dir / "build.gradle.kts"
    gradle_groovy = module_dir / "build.gradle"
    gradle_text = _read(gradle_kts) if gradle_kts.exists() else _read(gradle_groovy)

    gradle_info = _parse_gradle_file(gradle_text)
    manifest_path = module_dir / "src" / "main" / "AndroidManifest.xml"
    manifest_info = _parse_manifest(manifest_path)

    return ModuleMetadata(
        name=module_name,
        application_id=gradle_info["application_id"] or manifest_info["package"],
        compile_sdk=gradle_info["compile_sdk"],
        min_sdk=gradle_info["min_sdk"],
        target_sdk=gradle_info["target_sdk"],
        uses_kotlin=gradle_info["uses_kotlin"],
        uses_compose=gradle_info["uses_compose"],
        dependencies=gradle_info["dependencies"],
        activities=manifest_info["activities"],
        permissions=manifest_info["permissions"],
    )


def scan_project(root_dir: str, module_dirs: list, gradle_type: Optional[str]) -> ProjectMetadata:
    root = Path(root_dir)
    warnings = []
    modules = []

    for module_name in module_dirs:
        try:
            modules.append(scan_module(root, module_name).__dict__)
        except Exception as e:
            warnings.append(f"Failed to scan module '{module_name}': {e}")

    return ProjectMetadata(
        root_dir=str(root),
        gradle_type=gradle_type,
        modules=modules,
        warnings=warnings,
    )


if __name__ == "__main__":
    import sys
    from project_detector import detect

    if len(sys.argv) != 2:
        print("Usage: python scanner.py <extracted_dir>")
        sys.exit(1)

    detection = detect(sys.argv[1])
    if not detection.is_android_project:
        print(json.dumps({"error": "not_an_android_project", "reasons": detection.reasons}, indent=2))
        sys.exit(1)

    metadata = scan_project(detection.root_dir, detection.module_dirs, detection.gradle_type)
    print(json.dumps(asdict(metadata), indent=2, ensure_ascii=False))
