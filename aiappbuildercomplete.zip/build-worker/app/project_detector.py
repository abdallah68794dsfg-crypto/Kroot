"""
project_detector.py
Determines whether an extracted directory is a valid Android/Gradle project,
and collects top-level facts needed before deeper analysis.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class DetectionResult:
    is_android_project: bool
    root_dir: str
    gradle_type: Optional[str] = None       # "kts" | "groovy" | None
    has_wrapper: bool = False
    has_compose_hint: bool = False
    module_dirs: list = field(default_factory=list)   # e.g. ["app"]
    language: Optional[str] = None          # "kotlin" | "java" | "mixed" | None
    reasons: list = field(default_factory=list)


def _find_root(extracted_dir: str) -> str:
    """
    Some archives wrap the project in a single top-level folder
    (e.g. my-app.zip -> my-app/app/...). Detect and descend into it.
    """
    entries = [e for e in os.listdir(extracted_dir) if not e.startswith("__MACOSX")]
    if len(entries) == 1:
        candidate = os.path.join(extracted_dir, entries[0])
        if os.path.isdir(candidate):
            return candidate
    return extracted_dir


def detect(extracted_dir: str) -> DetectionResult:
    root = _find_root(extracted_dir)
    reasons = []

    settings_kts = os.path.exists(os.path.join(root, "settings.gradle.kts"))
    settings_groovy = os.path.exists(os.path.join(root, "settings.gradle"))
    build_kts = os.path.exists(os.path.join(root, "build.gradle.kts"))
    build_groovy = os.path.exists(os.path.join(root, "build.gradle"))
    gradlew = os.path.exists(os.path.join(root, "gradlew"))

    gradle_type = None
    if settings_kts or build_kts:
        gradle_type = "kts"
    elif settings_groovy or build_groovy:
        gradle_type = "groovy"

    if not (settings_kts or settings_groovy):
        reasons.append("No settings.gradle(.kts) found at project root")

    module_dirs = []
    for entry in os.listdir(root):
        full = os.path.join(root, entry)
        if os.path.isdir(full):
            manifest = os.path.join(full, "src", "main", "AndroidManifest.xml")
            if os.path.exists(manifest):
                module_dirs.append(entry)

    if not module_dirs:
        reasons.append("No module with src/main/AndroidManifest.xml found")

    is_android_project = bool((settings_kts or settings_groovy) and module_dirs)

    # crude language + Compose hints (cheap heuristics; scanner.py does the real parsing)
    has_compose_hint = False
    language_hint = None
    kt_count = 0
    java_count = 0
    for module in module_dirs:
        src_main = Path(root) / module / "src" / "main"
        if not src_main.exists():
            continue
        for path in src_main.rglob("*"):
            if path.suffix == ".kt":
                kt_count += 1
            elif path.suffix == ".java":
                java_count += 1
        for gradle_file in [
            Path(root) / module / "build.gradle.kts",
            Path(root) / module / "build.gradle",
        ]:
            if gradle_file.exists():
                text = gradle_file.read_text(errors="ignore")
                if "compose" in text.lower():
                    has_compose_hint = True

    if kt_count and java_count:
        language_hint = "mixed"
    elif kt_count:
        language_hint = "kotlin"
    elif java_count:
        language_hint = "java"

    return DetectionResult(
        is_android_project=is_android_project,
        root_dir=root,
        gradle_type=gradle_type,
        has_wrapper=gradlew,
        has_compose_hint=has_compose_hint,
        module_dirs=module_dirs,
        language=language_hint,
        reasons=reasons,
    )


if __name__ == "__main__":
    import sys
    import json
    from dataclasses import asdict

    if len(sys.argv) != 2:
        print("Usage: python project_detector.py <extracted_dir>")
        sys.exit(1)

    result = detect(sys.argv[1])
    print(json.dumps(asdict(result), indent=2, ensure_ascii=False))
