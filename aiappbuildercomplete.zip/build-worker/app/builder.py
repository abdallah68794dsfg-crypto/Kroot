from pathlib import Path
import subprocess
def build_apk(root:Path):
 subprocess.run(['./gradlew','assembleDebug','--no-daemon'],cwd=root,check=True,timeout=900)
 apks=list(root.glob('app/build/outputs/apk/debug/*.apk'))
 if not apks: raise RuntimeError('APK not found')
 return apks[0]
