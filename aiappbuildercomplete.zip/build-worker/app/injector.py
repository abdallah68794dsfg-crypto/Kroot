from pathlib import Path
import os,shutil
def inject_project(p,j):
 root=Path(os.getenv('WORK_DIR','/workspace/temp_builds'))/j; shutil.copytree(Path(os.getenv('TEMPLATE_DIR','/workspace/android-template')),root)
 main=root/'app/src/main/java/com/generated/app/MainActivity.kt';main.write_text(p['mainActivity'])
 for name,content in p.get('files',{}).items(): t=root/name;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(content)
 return root
