import json, os, traceback
from pathlib import Path
from redis import Redis

from injector import inject_project
from builder import build_apk
from uploader import upload

from archive_handler import extract_project, cleanup_workspace, ArchiveError
from project_detector import detect
from scanner import scan_project

r = Redis.from_url(os.getenv('REDIS_URL', 'redis://redis:6379'), decode_responses=True)
QUEUE = os.getenv('BUILD_QUEUE', 'apk-builds')


def handle_generate_job(job: dict):
    """Existing flow: AI-generated project dict -> inject into template -> build -> upload."""
    root = inject_project(job['project'], job['id'])
    apk = build_apk(root)
    return upload(apk, job['id'])


def handle_convert_job(job: dict):
    """
    New flow: user uploaded an existing Android project archive.
    job = {"id": ..., "type": "convert", "archive_path": "/path/on/shared/volume/project.zip"}
    """
    archive_path = job['archive_path']
    workspace = extract_project(archive_path, workspace_root=os.getenv('WORK_DIR', '/workspace/temp_builds'))
    try:
        detection = detect(workspace)
        if not detection.is_android_project:
            raise RuntimeError(f"Not a valid Android project: {detection.reasons}")

        metadata = scan_project(detection.root_dir, detection.module_dirs, detection.gradle_type)
        print(f"[job={job['id']}] metadata:", json.dumps(metadata.__dict__)[:500])

        if not detection.has_wrapper:
            raise RuntimeError("Project has no gradlew — cannot build without a Gradle wrapper")

        # NOTE: this reuses the same build_apk() the generate-flow uses,
        # since both ultimately just need `./gradlew assembleDebug` run
        # against a project root that has a valid Gradle wrapper.
        apk = build_apk(Path(detection.root_dir))
        return upload(apk, job['id'])
    finally:
        cleanup_workspace(workspace)


def main():
    print(f"Build worker started, listening on queue '{QUEUE}'...")
    while True:
        item = r.brpop(QUEUE, timeout=5)
        if not item:
            continue
        _, raw = item
        job = json.loads(raw)
        job_id = job.get('id', 'unknown')
        job_type = job.get('type', 'generate')  # default to old behavior for back-compat

        try:
            if job_type == 'convert':
                result = handle_convert_job(job)
            else:
                result = handle_generate_job(job)
            r.set(f"job:{job_id}:status", "completed")
            r.set(f"job:{job_id}:result", result)
            print(f"[job={job_id}] completed -> {result}")
        except ArchiveError as e:
            r.set(f"job:{job_id}:status", "failed")
            r.set(f"job:{job_id}:error", f"Archive error: {e}")
            print('BUILD FAILED (archive)', job_id, e)
        except Exception as e:
            r.set(f"job:{job_id}:status", "failed")
            r.set(f"job:{job_id}:error", str(e))
            print('BUILD FAILED', job_id, e)
            traceback.print_exc()


if __name__ == '__main__':
    main()
