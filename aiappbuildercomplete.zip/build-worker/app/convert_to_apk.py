"""
convert_to_apk.py
Single entry point that ties the whole pipeline together:

    archive (.zip/.tar.gz) -> extract -> detect -> scan -> build -> APK

Usage:
    python3 convert_to_apk.py /path/to/project.zip [--task assembleDebug] [--out ./output]

This MUST be run inside the build-worker container (or an environment with
JDK 17 + Android SDK + build-tools installed) — see services/build-worker/Dockerfile.
It will NOT produce a real APK in a plain Python environment without those
installed; it will fail loudly at the Gradle step and tell you why.
"""

import argparse
import json
import shutil
import sys
from pathlib import Path

from archive_handler import extract_project, cleanup_workspace, ArchiveError
from project_detector import detect
from scanner import scan_project
from builder import build_with_repair_loop, MAX_REPAIR_ATTEMPTS


def convert(archive_path: str, task: str, out_dir: str, keep_workspace: bool = False) -> int:
    archive_path = str(Path(archive_path).resolve())
    out_path = Path(out_dir).resolve()
    out_path.mkdir(parents=True, exist_ok=True)

    print(f"[1/5] استخراج الأرشيف: {archive_path}")
    try:
        workspace = extract_project(archive_path)
    except ArchiveError as e:
        print(f"❌ فشل الاستخراج: {e}")
        return 1

    try:
        print("[2/5] فحص المشروع (هل هو Android/Gradle صالح؟)")
        detection = detect(workspace)
        if not detection.is_android_project:
            print("❌ هذا ليس مشروع Android صالح:")
            for reason in detection.reasons:
                print(f"   - {reason}")
            return 2
        print(f"   ✅ وُجد {len(detection.module_dirs)} module(s): {detection.module_dirs}")
        print(f"   Gradle: {detection.gradle_type} | Compose hint: {detection.has_compose_hint} | wrapper: {detection.has_wrapper}")

        print("[3/5] تحليل تفصيلي (dependencies, SDK versions, manifest)")
        metadata = scan_project(detection.root_dir, detection.module_dirs, detection.gradle_type)
        metadata_path = out_path / "project_metadata.json"
        metadata_path.write_text(json.dumps(metadata.__dict__, indent=2, ensure_ascii=False))
        print(f"   💾 حُفظت الـmetadata في: {metadata_path}")
        for w in metadata.warnings:
            print(f"   ⚠️ {w}")

        if not detection.has_wrapper:
            print("❌ لا يوجد gradlew (Gradle wrapper) في المشروع — لا يمكن البناء بدونه.")
            print("   حل: أضف الـwrapper إلى المشروع قبل الرفع (gradle wrapper) ثم أعد المحاولة.")
            return 3

        print(f"[4/5] البناء (Gradle task: {task}, حتى {MAX_REPAIR_ATTEMPTS} محاولات إصلاح)")
        result, attempts = build_with_repair_loop(detection.root_dir, repair_fn=None)

        if not result.success:
            print(f"❌ فشل البناء بعد {attempts} محاولة/محاولات.")
            if result.classified_errors:
                print("   الأخطاء المكتشفة:")
                for err in result.classified_errors:
                    print(f"   - [{err['type']}] {err['detail']}")
            else:
                print("   سجل الأخطاء (آخر جزء):")
                print("   " + result.stderr_tail[-800:].replace("\n", "\n   "))
            return 4

        print(f"[5/5] نجح البناء ✅ ({attempts} محاولة)")
        copied = []
        for apk_path in result.apk_paths:
            dest = out_path / Path(apk_path).name
            shutil.copy2(apk_path, dest)
            copied.append(str(dest))
            print(f"   📦 APK: {dest}")

        if not copied:
            print("   ⚠️ البناء نجح لكن لم يُعثر على ملف APK — تحقق من مسار outputs/ في المشروع.")
            return 5

        return 0

    finally:
        if not keep_workspace:
            cleanup_workspace(workspace)
        else:
            print(f"(تم الإبقاء على مجلد العمل للتفتيش: {workspace})")


def main():
    parser = argparse.ArgumentParser(description="Convert an uploaded Android project archive into an APK.")
    parser.add_argument("archive", help="Path to .zip or .tar.gz project archive")
    parser.add_argument("--task", default="assembleDebug", help="Gradle task to run (default: assembleDebug)")
    parser.add_argument("--out", default="./output", help="Directory to write the APK + metadata into")
    parser.add_argument("--keep-workspace", action="store_true", help="Don't delete the extracted temp workspace (for debugging)")
    args = parser.parse_args()

    exit_code = convert(args.archive, args.task, args.out, args.keep_workspace)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
