import os,boto3
from pathlib import Path
def upload(apk:Path,job_id:str):
 bucket=os.getenv('S3_BUCKET')
 if not bucket:return str(apk)
 key=f'apks/{job_id}/{apk.name}';boto3.client('s3',region_name=os.getenv('AWS_REGION')).upload_file(str(apk),bucket,key,ExtraArgs={'ContentType':'application/vnd.android.package-archive'});return key
