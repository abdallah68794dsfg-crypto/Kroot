#!/bin/sh
set -eu
./gradlew assembleDebug --no-daemon
