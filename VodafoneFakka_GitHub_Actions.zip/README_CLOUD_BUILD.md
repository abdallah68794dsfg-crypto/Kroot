# بناء APK من الهاتف عبر GitHub Actions

1. أنشئ Repository جديد على GitHub.
2. ارفع كل محتويات هذا المجلد إلى المستودع، بما فيها `.github/workflows/build-apk.yml`.
3. افتح تبويب Actions.
4. اختر `Build Android APK`.
5. اضغط `Run workflow`.
6. بعد انتهاء البناء افتح نتيجة التشغيل ثم قسم Artifacts.
7. نزّل `VodafoneFakka-debug` وفك الضغط، وستجد `app-debug.apk`.

لا تحتاج Android Studio على الهاتف؛ عملية البناء تتم على خوادم GitHub Actions.
