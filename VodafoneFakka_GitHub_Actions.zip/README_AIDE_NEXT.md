# VodafoneFakka — AIDE Next

1. فك الضغط.
2. افتح AIDE Next.
3. Open Project ثم اختر مجلد VodafoneFakka.
4. انتظر Gradle Sync.
5. Build > Assemble Debug.
6. ستجد APK في:
   app/build/outputs/apk/debug/app-debug.apk

المشروع مضبوط على Android Gradle Plugin 8.11.0 وGradle 8.13.
