package com.example.vodafonefakka

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val products = listOf(
        "فكة 2.5 جنيه" to "Fakka_2.5_Unite",
        "فكة 4.25 جنيه" to "Fakka_4.25_Unite",
        "فكة 5 جنيه" to "Fakka_5_Unite",
        "فكة 6 جنيه" to "Fakka_6_NewUnite",
        "فكة 7 جنيه" to "Fakka_7_Unite",
        "فكة 9 جنيه" to "Fakka_9_Unite",
        "فكة 10 جنيه" to "Fakka_10_Unite",
        "فكة 10 جنيه (new)" to "Fakka_10_NewUnite",
        "فكة 10.5 جنيه" to "Fakka_10.5_Unite",
        "فكة 11.5 جنيه" to "Fakka_11.5_Unite",
        "فكة 12 جنيه" to "Fakka_12_Unite",
        "فكة 12.5 جنيه" to "Fakka_12.5_Unite",
        "فكة 13 جنيه" to "Fakka_13_Unite",
        "فكة 13.5 جنيه" to "Fakka_13.5_Unite",
        "فكة 15 جنيه" to "Fakka_15_Unite",
        "فكة 15 جنيه (new)" to "Fakka_15_NewUnite",
        "فكة 15.5 جنيه" to "Fakka_15.5_Unite",
        "فكة 16.5 جنيه" to "Fakka_16.5_Unite",
        "فكة 17.5 جنيه" to "Fakka_17.5_Unite",
        "فكة 19.5 جنيه" to "Fakka_19.5_NewUnite",
        "فكة 20 جنيه" to "Fakka_20_Unite",
        "فكة 26 جنيه" to "Fakka_26_Unite",
        "مارد 10 دقايق" to "Mared_10_Minuts",
        "مارد 10 فليكس" to "Mared_10_Flexs",
        "مارد 10 سوشيال" to "Mared_10_Social"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinner = findViewById<Spinner>(R.id.productSpinner)
        val receiver = findViewById<EditText>(R.id.receiverEdit)
        val pin = findViewById<EditText>(R.id.pinEdit)
        val button = findViewById<Button>(R.id.chargeButton)
        val status = findViewById<TextView>(R.id.statusText)

        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            products.map { it.first })

        button.setOnClickListener {
            val number = receiver.text.toString().trim()
            val password = pin.text.toString().trim()
            if (!number.startsWith("01") || number.length != 11) {
                status.text = "❌ رقم غير صحيح"
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                status.text = "❌ أدخل الرقم السري للمحفظة"
                return@setOnClickListener
            }

            val productId = products[spinner.selectedItemPosition].second
            button.isEnabled = false
            status.text = "⏳ جارٍ التنفيذ..."

            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runRequest(productId, number, password)
                }
                status.text = result
                button.isEnabled = true
            }
        }
    }

    private fun runRequest(productId: String, receiver: String, pin: String): String {
        return try {
            // نفس عناوين وبيانات الخدمة الموجودة في ملف Python المرفوع.
            val seamlessUrl = "http://mobile.vodafone.com.eg/checkSeamless/realms/vf-realm/protocol/openid-connect/auth?client_id=ana-vodafone-app-seamless"
            val seamless = getJson(seamlessUrl, mapOf(
                "User-Agent" to "okhttp/4.11.0",
                "Accept-Language" to "ar",
                "clientId" to "AnaVodafoneAndroid",
                "x-agent-operatingsystem" to "13",
                "x-agent-device" to "OPPO CPH2235",
                "x-agent-version" to "2024.7.2.1",
                "x-agent-build" to "1050",
                "digitalId" to "24S0M31T0I9RK"
            ))
            val seamlessToken = seamless.optString("seamlessToken")
            val sender = seamless.optString("msisdn")
            if (seamlessToken.isEmpty()) return "❌ تعذر تسجيل الدخول إلى الكاش"

            val tokenUrl = "https://mobile.vodafone.com.eg/auth/realms/vf-realm/protocol/openid-connect/token"
            val tokenData = "grant_type=password&client_secret=b86e30a8-ae29-467a-a71f-65c73f2ff5e3&client_id=cash-app"
            val token = postJson(tokenUrl, tokenData, mapOf(
                "User-Agent" to "okhttp/4.11.0",
                "Accept" to "application/json, text/plain, */*",
                "Content-Type" to "application/x-www-form-urlencoded",
                "silentLogin" to "true",
                "seamlessToken" to seamlessToken,
                "firstTimeLogin" to "true",
                "Accept-Language" to "ar",
                "clientId" to "AnaVodafoneAndroid",
                "x-agent-operatingsystem" to "13",
                "x-agent-device" to "OPPO CPH2235",
                "x-agent-version" to "2024.7.2.1",
                "x-agent-build" to "1050",
                "digitalId" to "24S0M31T0I9RK"
            )).getString("access_token")

            val order = JSONObject().apply {
                put("channel", JSONObject().put("name", "MobileApp"))
                put("orderItem", org.json.JSONArray().put(JSONObject().apply {
                    put("action", "insert")
                    put("id", productId)
                    put("product", JSONObject().apply {
                        put("characteristic", org.json.JSONArray()
                            .put(JSONObject().put("name","PaymentMethod").put("value","VFCash"))
                            .put(JSONObject().put("name","USE_EMONEY").put("value","False"))
                            .put(JSONObject().put("name","MerchantCode").put("value","")))
                        put("id", productId)
                        put("relatedParty", org.json.JSONArray()
                            .put(JSONObject().put("id", sender).put("name","MSISDN").put("role","Subscriber"))
                            .put(JSONObject().put("id", receiver).put("name","Receiver").put("role","Receiver")))
                    })
                    put("@type", productId)
                    put("eCode", 0)
                }))
                put("relatedParty", org.json.JSONArray().put(
                    JSONObject().put("id", pin).put("name","pin").put("role","Requestor")
                ))
                put("@type", "CashFakkaAndMared")
            }

            val msisdn = if (sender.isNotEmpty() && !sender.startsWith("0")) "0$sender" else sender
            val response = postJson(
                "https://mobile.vodafone.com.eg/services/dxl/pom/productOrder",
                order.toString(),
                mapOf(
                    "User-Agent" to "okhttp/4.11.0",
                    "Accept" to "application/json",
                    "Content-Type" to "application/json",
                    "api-host" to "ProductOrderingManagement",
                    "useCase" to "CashFakkaAndMared",
                    "api-version" to "v2",
                    "msisdn" to msisdn,
                    "Authorization" to "Bearer $token",
                    "Accept-Language" to "ar",
                    "clientId" to "AnaVodafoneAndroid",
                    "x-agent-operatingsystem" to "13",
                    "x-agent-device" to "OPPO CPH2235",
                    "x-agent-version" to "2024.7.2.1",
                    "x-agent-build" to "1050",
                    "digitalId" to "24S0M31T0I9RK"
                )
            )
            if (response.optString("state") == "Completed" || response.optBoolean("complete"))
                "✅ تم الشحن بنجاح!"
            else
                "❌ فشل: رصيدك غير كافي أو خطأ آخر\n$response"
        } catch (e: Exception) {
            "❌ خطأ: ${e.message}"
        }
    }

    private fun getJson(url: String, headers: Map<String,String>): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        headers.forEach { (k,v) -> c.setRequestProperty(k,v) }
        c.requestMethod = "GET"
        return JSONObject(c.inputStream.bufferedReader().readText())
    }

    private fun postJson(url: String, body: String, headers: Map<String,String>): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.doOutput = true
        c.requestMethod = "POST"
        headers.forEach { (k,v) -> c.setRequestProperty(k,v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        return JSONObject(c.inputStream.bufferedReader().readText())
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
